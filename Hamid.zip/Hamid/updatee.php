<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "logintable";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name= $_POST["name"];
$pid= $_POST["id"];
$age= $_POST["age"];
$salary=$_POST["salary"];
$sql = "UPDATE information SET name= '$name' , age='$age' , salary='$salary' WHERE pid=$pid";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>