<?php
class User {
  // Properties
  public $name;
  public $age;
  public $salary;

  // Methods
  function set_name($name) {
    $this->name = $name;
  }
  function get_name() {
    return $this->name;
  }

 function set_age($age) {
    $this->age = $age;
  }
  function get_age() {
    return $this->age;
  }

 function set_salary($salary) {
    $this->salary = $salary;
  }
  function get_salary() {
   return $this->salary;
  }



}

?>


<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "DB";

$u = new User();

$u->set_name($_POST["name"]);
$u->set_age($_POST["age"]);
$u->set_salary($_POST["salary"]);


$name= $u->get_name();

$age= $u->get_age();

$salary= $u->get_salary();


// Create connection
$conn = new mysqli($servername, $username, $password, $testdb);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO product (name, age, salary)
VALUES ($name,$age,$salary)";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>