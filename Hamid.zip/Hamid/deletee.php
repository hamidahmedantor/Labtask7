
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "logintable";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$pid= $_POST["id"];

// sql to delete a record
$sql = "DELETE FROM information WHERE pid= $pid";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>