<?php

	$con=mysqli_connect("localhost","root","","logintable");
	if(!$con)
	{
		die("Connection Error: ".mysqli_connect_error()."<br/>");
	}

	$sql="SELECT * FROM information";
	$result=mysqli_query($con,$sql);
	if(mysqli_num_rows($result)>0)
	 {
	 	?>
	 	<table>
	 		<tr>
	 			<th>Employee ID</th>
	 			<th>Employee Name</th>
	 			<th>Age</th>
	 			<th>Salary</th>
	 		</tr>
	 	<?php
	 	while($row=mysqli_fetch_array($result))
	 	{
	 		echo "<tr>";
	 		echo "<td>".$row['pid']."</td>";
	 		echo "<td>".$row['name']."</td>";
	 		echo "<td>".$row['age']."</td>";
	 		echo "<td>".$row['salary']."</td>";
	 		echo "</tr>";

	 	
	 	}
	 	echo "</table>";
	 }
	 else
	 {
	 	echo "No data found.<br/>";
	 }
mysqli_close($con);	